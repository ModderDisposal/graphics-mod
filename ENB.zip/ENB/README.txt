Drag & drop the files in the "Files" folder to your base "Grand Theft Auto V" folder
~ Spinethetic