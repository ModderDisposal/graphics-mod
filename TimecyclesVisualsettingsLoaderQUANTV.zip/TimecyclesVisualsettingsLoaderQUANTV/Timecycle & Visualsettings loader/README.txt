Drag & drop the files in the "Files" folder to your base "Grand Theft Auto V" folder
Once storymode has loaded, press the F10 key to activate UnknownModder's VSReloader.asi plugin into loading my configurations from the VSReloader folder.
~ Spinethetic

The contained timecycle and visualsettings files are made by Quant, which can be fetched and LIKED here: https://www.gtainside.com/en/gta5/mods/119996-quantv-2-1-4/
The contained "VSReloader.asi" file inherent in each set, is made by UnknownModder, which can be fetched and LIKED here: https://www.gta5-mods.com/tools/visualsettings-dat-reloader
