1- Drag Xenos64.exe(injector), openiv.dll(the /mods loader), and OpenMeBeforeLoadingGTAV.xpr64 and put them wherever you want.
2- Right click and open "OpenMeBeforeLoadingGTAV.xpr64" and edit in either Notepad or Notepad++.
3- On line #2 where you see <imagePath>, edit this to the full location on your hard drive of the openiv.dll file.
4- On line #4 where you see <procName>, edit this to the full location on your hard drive of your GTA5.exe.
5- On line #13 where you see <delay>, this will take some trial and error on your part and depends on your processer power on what the value here is to be set in milliseconds (8000 is equal to 8 seconds, 10000 is equal to 10 seconds). Adjust this until you can visually verify that the game looks much better. (of course it goes without saying that your GTA graphics settings should be all set to the highest you can).
6- Save the file somewhere easy to find, as every time you load GTAV, you simply need to double click it in order for the overhaul load.
~Spinethetic

ps: the trees, extra scenery, and the 2 mansions, will only appear online, not in storymode. (mansions are located one in Vinewood Hills, and the other on the side of Mt. Chiliad)