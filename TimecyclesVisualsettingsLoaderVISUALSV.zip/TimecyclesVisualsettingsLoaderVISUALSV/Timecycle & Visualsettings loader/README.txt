Drag & drop the files in the "Files" folder to your base "Grand Theft Auto V" folder
Once storymode has loaded, press the F10 key to activate UnknownModder's VSReloader.asi plugin into loading my configurations from the VSReloader folder.
~ Spinethetic

The contained timecycle and visualsettings files are made by _CP_ & robi29, which can be fetched and LIKED here: https://www.gta5-mods.com/misc/visualv
The contained "VSReloader.asi" file inherent in each set, is made by UnknownModder, which can be fetched and LIKED here: https://www.gta5-mods.com/tools/visualsettings-dat-reloader
